#include <stdio.h>
  int main() {
  printf("¡Hola Mundo!");  // Imprime el texto "¡Hola Mundo!" en la consola
  return 0;  // Indica que el programa terminó exitosamente
}
