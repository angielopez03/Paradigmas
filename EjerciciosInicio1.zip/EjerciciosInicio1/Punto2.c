#include <stdio.h>
  int main() {
  char saludo[] = "¡Hola Mundo!";  // Declara un arreglo de caracteres (cadena) e inicializa con "¡Hola Mundo!"
  printf("%s", saludo);  // Imprime el contenido de la variable 'saludo' en la consola usando el formato de cadena (%s)
    
  return 0;  // Indica que el programa terminó exitosamente
}

